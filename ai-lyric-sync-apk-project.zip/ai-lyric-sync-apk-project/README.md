# AI Lyric Sync — Installable Android APK Project

This project wraps `ai-lyric-sync16.html` into a full-featured **Android APK** (Capacitor 6 + Native Embedded Localhost Server + Whisper AI Agents + Android MediaStore Gallery Export).

## What Was Upgraded for Android APK
1. **Embedded Native Localhost Video Server (`LocalHostServer.java` on `http://127.0.0.1:8765`)**:
   - Supports **HTTP 206 Byte-Range streaming** with CORS (`Access-Control-Allow-Origin: *`), eliminating Android `content://`/`file://` canvas tainting and allowing 2GB+ video playback without OutOfMemory crashes.
   - **Native Video Picker (`LocalVideoPlugin.pickVideo`)**: Streams videos directly from Android storage via `ACTION_OPEN_DOCUMENT` to `http://127.0.0.1:8765/video/<id>`.
   - **Localhost & Wi-Fi Video Upload (`POST /upload` & `/upload-ui`)**: Upload a video directly inside the app OR open `http://<phone-ip>:8765/upload-ui` from any PC/device on the same Wi-Fi to push videos straight into the APK.
2. **Whisper AI Agent Integration**:
   - **On-Device Agent (Offline after first download)**: Runs `whisper-tiny`, `whisper-base`, and `whisper-small` locally in Android WebView via `@huggingface/transformers@3.4.0` (ONNX/WASM, Q8 quantized, WebView-safe threading).
   - **External / Localhost Whisper API Agent**: Connects to any OpenAI-compatible transcription endpoint (`whisper.cpp` server, Faster-Whisper, Groq, OpenAI) by encoding 16kHz WAV audio and parsing word/segment timestamps directly into the Arabic alignment engine.
3. **Native Android Export (`POST /save`)**:
   - Fixes Android WebView's broken `a.download` blob downloads by streaming exported MP4s straight into `Movies/LyricSync` (visible in Gallery) and `.srt` files into `Downloads/LyricSync` via `MediaStore`.
4. **Screen Wake Lock & Large Heap**:
   - Configured `android:largeHeap="true"`, `android:hardwareAccelerated="true"`, `android:usesCleartextTraffic="true"`, and native `FLAG_KEEP_SCREEN_ON` during Whisper sync and MP4 rendering.

---

## Option A: Build the Installable `.apk` Automatically via GitHub Actions (No Android Studio Needed)
1. Unzip this folder and push it to a new GitHub repository.
2. Go to the **Actions** tab in GitHub and run **Build Android APK** (or push to `main`).
3. Wait ~3 minutes, then download the **`ai-lyric-sync-debug-apk`** artifact containing `app-debug.apk`.
4. Transfer `app-debug.apk` to your Android phone and install it (enable *Install unknown apps* if prompted).

## Option B: Build Locally (Windows / macOS / Linux)
Requirements: **Node.js 18+**, **JDK 17**, and **Android SDK** (via Android Studio or command-line tools).

### macOS / Linux
```bash
chmod +x build-apk.sh
./build-apk.sh
```

### Windows
Double-click `build-apk.bat` or run in Command Prompt:
```cmd
build-apk.bat
```

The installable APK will be created at:
```
android/app/build/outputs/apk/debug/app-debug.apk
```

## Option C: Test Immediately on Localhost (Desktop / LAN)
```bash
npm run dev
```
Open `http://127.0.0.1:8765` in Chrome.
