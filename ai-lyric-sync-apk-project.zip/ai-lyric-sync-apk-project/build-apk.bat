@echo off
echo === Installing dependencies ===
call npm install || exit /b 1
if not exist android (
  echo === Creating Android platform ===
  call npx cap add android || exit /b 1
)
echo === Applying LocalHostServer & Whisper WebView patches ===
call node scripts/patch-android.js || exit /b 1
call npx cap sync android || exit /b 1
echo === Building installable Debug APK ===
cd android
call gradlew.bat assembleDebug || exit /b 1
echo.
echo SUCCESS! Installable APK ready at:
echo   android\app\build\outputs\apk\debug\app-debug.apk
pause
