const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');

const PORT = Number(process.env.PORT || 8765);
const WWW_DIR = path.join(__dirname, 'www');
const UPLOAD_DIR = path.join(__dirname, '.localhost_uploads');
const EXPORT_DIR = path.join(__dirname, 'exports');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });
fs.mkdirSync(EXPORT_DIR, { recursive: true });

const videos = new Map();
let currentVideo = null;

function getLanIp() {
  for (const list of Object.values(os.networkInterfaces())) {
    for (const ni of list || []) {
      if (ni.family === 'IPv4' && !ni.internal) return ni.address;
    }
  }
  return '127.0.0.1';
}

function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, HEAD');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Range, X-File-Name, Authorization');
  res.setHeader('Access-Control-Expose-Headers', 'Content-Length, Content-Range, Accept-Ranges');
}

function mimeFor(f) {
  const ext = path.extname(f).toLowerCase();
  return ({
    '.html': 'text/html; charset=utf-8',
    '.js': 'application/javascript; charset=utf-8',
    '.css': 'text/css; charset=utf-8',
    '.mp4': 'video/mp4',
    '.webm': 'video/webm',
    '.mov': 'video/quicktime',
    '.mkv': 'video/x-matroska',
    '.srt': 'text/plain; charset=utf-8',
    '.json': 'application/json; charset=utf-8'
  })[ext] || 'application/octet-stream';
}

const server = http.createServer((req, res) => {
  cors(res);
  if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }

  const urlObj = new URL(req.url, `http://127.0.0.1:${PORT}`);
  const p = urlObj.pathname;

  if (req.method === 'GET' && (p === '/status' || p === '/current')) {
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    return res.end(JSON.stringify({
      ok: true,
      port: PORT,
      url: `http://127.0.0.1:${PORT}`,
      lanUrl: `http://${getLanIp()}:${PORT}`,
      currentVideo
    }));
  }

  if (req.method === 'POST' && p === '/upload') {
    const rawName = urlObj.searchParams.get('name') || req.headers['x-file-name'] || 'video.mp4';
    const safeName = rawName.replace(/[\\/:*?"<>|]/g, '_');
    const id = crypto.randomBytes(6).toString('hex');
    const outPath = path.join(UPLOAD_DIR, `${id}_${safeName}`);
    const ws = fs.createWriteStream(outPath);
    req.pipe(ws);
    ws.on('finish', () => {
      const stat = fs.statSync(outPath);
      const entry = {
        id,
        name: safeName,
        size: stat.size,
        mime: urlObj.searchParams.get('mime') || mimeFor(safeName),
        filePath: outPath,
        url: `http://127.0.0.1:${PORT}/video/${id}`
      };
      videos.set(id, entry);
      currentVideo = { id: entry.id, name: entry.name, size: entry.size, mime: entry.mime, url: entry.url };
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
      res.end(JSON.stringify({ ok: true, ...currentVideo }));
    });
    return;
  }

  if (req.method === 'POST' && p === '/save') {
    const rawName = urlObj.searchParams.get('name') || `export-${Date.now()}.mp4`;
    const safeName = rawName.replace(/[\\/:*?"<>|]/g, '_');
    const outPath = path.join(EXPORT_DIR, safeName);
    const ws = fs.createWriteStream(outPath);
    req.pipe(ws);
    ws.on('finish', () => {
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
      res.end(JSON.stringify({ ok: true, savedPath: outPath }));
    });
    return;
  }

  if ((req.method === 'GET' || req.method === 'HEAD') && p.startsWith('/video/')) {
    const id = p.slice('/video/'.length).split('.')[0];
    const entry = id === 'current' && currentVideo ? videos.get(currentVideo.id) : videos.get(id);
    if (!entry || !fs.existsSync(entry.filePath)) {
      res.writeHead(404); return res.end('Video not found');
    }
    const total = fs.statSync(entry.filePath).size;
    const range = req.headers.range;
    if (range) {
      const [s, e] = range.replace(/bytes=/, '').split('-');
      const start = parseInt(s, 10);
      const end = e ? Math.min(parseInt(e, 10), total - 1) : total - 1;
      res.writeHead(206, {
        'Content-Range': `bytes ${start}-${end}/${total}`,
        'Accept-Ranges': 'bytes',
        'Content-Length': end - start + 1,
        'Content-Type': entry.mime
      });
      if (req.method === 'HEAD') return res.end();
      return fs.createReadStream(entry.filePath, { start, end }).pipe(res);
    }
    res.writeHead(200, { 'Content-Length': total, 'Accept-Ranges': 'bytes', 'Content-Type': entry.mime });
    if (req.method === 'HEAD') return res.end();
    return fs.createReadStream(entry.filePath).pipe(res);
  }

  // Serve static app from www/
  const rel = p === '/' ? 'index.html' : p.replace(/^\/+/, '');
  const full = path.join(WWW_DIR, rel);
  if (full.startsWith(WWW_DIR) && fs.existsSync(full) && fs.statSync(full).isFile()) {
    res.writeHead(200, { 'Content-Type': mimeFor(full) });
    return fs.createReadStream(full).pipe(res);
  }
  res.writeHead(404); res.end('Not found');
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`AI Lyric Sync Localhost Server running at:`);
  console.log(`  Local: http://127.0.0.1:${PORT}`);
  console.log(`  LAN:   http://${getLanIp()}:${PORT}`);
});
