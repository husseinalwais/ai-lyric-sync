#!/usr/bin/env bash
set -euo pipefail
echo "=== Installing dependencies ==="
npm install
if [ ! -d "android" ]; then
  echo "=== Creating Android platform ==="
  npx cap add android
fi
echo "=== Applying LocalHostServer & Whisper WebView patches ==="
node scripts/patch-android.js
npx cap sync android
echo "=== Building installable Debug APK ==="
cd android
chmod +x gradlew
./gradlew assembleDebug
echo ""
echo "SUCCESS! Installable APK ready at:"
echo "  android/app/build/outputs/apk/debug/app-debug.apk"
