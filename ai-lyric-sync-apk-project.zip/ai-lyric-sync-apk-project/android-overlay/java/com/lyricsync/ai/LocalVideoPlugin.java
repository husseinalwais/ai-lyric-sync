package com.lyricsync.ai;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.util.Log;
import android.view.WindowManager;

import androidx.activity.result.ActivityResult;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "LocalVideo")
public class LocalVideoPlugin extends Plugin {
    private static final String TAG = "LocalVideoPlugin";
    private LocalHostServer server;

    @Override
    public void load() {
        server = new LocalHostServer(getContext());
        try {
            server.start(8765);
        } catch (Exception e) {
            Log.e(TAG, "Failed to start LocalHostServer", e);
        }
    }

    @Override
    protected void handleOnDestroy() {
        if (server != null) server.stop();
        super.handleOnDestroy();
    }

    @PluginMethod
    public void getServerInfo(PluginCall call) {
        JSObject ret = new JSObject();
        ret.put("port", server.getPort());
        ret.put("url", server.getBaseUrl());
        ret.put("lanUrl", server.getLanUrl());
        LocalHostServer.VideoEntry cv = server.getCurrentVideo();
        if (cv != null) {
            JSObject v = new JSObject();
            v.put("id", cv.id);
            v.put("name", cv.name);
            v.put("size", cv.size);
            v.put("mime", cv.mime);
            v.put("url", server.getBaseUrl() + "/video/" + cv.id);
            ret.put("currentVideo", v);
        }
        call.resolve(ret);
    }

    @PluginMethod
    public void pickVideo(PluginCall call) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("video/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(call, intent, "onVideoPicked");
    }

    @ActivityCallback
    private void onVideoPicked(PluginCall call, ActivityResult result) {
        if (call == null) return;
        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null || result.getData().getData() == null) {
            call.reject("Video selection cancelled");
            return;
        }
        Uri uri = result.getData().getData();
        ContentResolver cr = getContext().getContentResolver();
        try {
            cr.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {}

        String name = "video.mp4";
        long size = 0;
        String mime = cr.getType(uri);
        try (Cursor cursor = cr.query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                int sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE);
                if (nameIdx >= 0) name = cursor.getString(nameIdx);
                if (sizeIdx >= 0) size = cursor.getLong(sizeIdx);
            }
        } catch (Exception ignored) {}

        LocalHostServer.VideoEntry entry = server.registerUri(uri, name, mime, size);
        JSObject ret = new JSObject();
        ret.put("id", entry.id);
        ret.put("name", entry.name);
        ret.put("size", entry.size);
        ret.put("mime", entry.mime);
        ret.put("url", server.getBaseUrl() + "/video/" + entry.id);
        call.resolve(ret);
    }

    @PluginMethod
    public void keepScreenOn(PluginCall call) {
        boolean enabled = Boolean.TRUE.equals(call.getBoolean("enabled", false));
        Activity act = getActivity();
        if (act != null) {
            act.runOnUiThread(() -> {
                if (enabled) {
                    act.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                } else {
                    act.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                }
            });
        }
        call.resolve();
    }
}
