package com.lyricsync.ai;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLDecoder;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LocalHostServer {
    private static final String TAG = "LocalHostServer";
    private final Context context;
    private ServerSocket serverSocket;
    private ExecutorService pool;
    private volatile boolean running = false;
    private int port = 8765;

    public static class VideoEntry {
        public final String id;
        public final String name;
        public final String mime;
        public final long size;
        public final File file;
        public final Uri uri;

        public VideoEntry(String id, String name, String mime, long size, File file, Uri uri) {
            this.id = id;
            this.name = name;
            this.mime = (mime == null || mime.isEmpty()) ? "video/mp4" : mime;
            this.size = size;
            this.file = file;
            this.uri = uri;
        }
    }

    private final Map<String, VideoEntry> videos = new ConcurrentHashMap<>();
    private volatile VideoEntry currentVideo = null;

    public LocalHostServer(Context context) {
        this.context = context.getApplicationContext();
    }

    public synchronized int start(int preferredPort) throws IOException {
        if (running) return port;
        IOException lastEx = null;
        for (int p = preferredPort; p < preferredPort + 15; p++) {
            try {
                serverSocket = new ServerSocket(p);
                port = p;
                lastEx = null;
                break;
            } catch (IOException e) {
                lastEx = e;
            }
        }
        if (lastEx != null) throw lastEx;
        running = true;
        pool = Executors.newCachedThreadPool();
        Thread acceptThread = new Thread(() -> {
            while (running && serverSocket != null && !serverSocket.isClosed()) {
                try {
                    Socket client = serverSocket.accept();
                    pool.execute(() -> handleClient(client));
                } catch (IOException e) {
                    if (running) Log.w(TAG, "Accept error: " + e.getMessage());
                }
            }
        }, "LocalHostServer-Accept");
        acceptThread.setDaemon(true);
        acceptThread.start();
        Log.i(TAG, "Started embedded localhost server on port " + port);
        return port;
    }

    public synchronized void stop() {
        running = false;
        try {
            if (serverSocket != null) serverSocket.close();
        } catch (IOException ignored) {}
        if (pool != null) pool.shutdownNow();
    }

    public int getPort() {
        return port;
    }

    public String getBaseUrl() {
        return "http://127.0.0.1:" + port;
    }

    public String getLanUrl() {
        String ip = getLocalIpAddress();
        return ip != null ? ("http://" + ip + ":" + port) : getBaseUrl();
    }

    public VideoEntry getCurrentVideo() {
        return currentVideo;
    }

    public VideoEntry registerUri(Uri uri, String name, String mime, long size) {
        String id = UUID.randomUUID().toString().replace("-", "").substring(0, 12);
        String safeName = (name == null || name.isEmpty()) ? ("video-" + id + ".mp4") : name;
        VideoEntry entry = new VideoEntry(id, safeName, mime, size, null, uri);
        videos.put(id, entry);
        currentVideo = entry;
        return entry;
    }

    public VideoEntry registerFile(File file, String name, String mime) {
        String id = UUID.randomUUID().toString().replace("-", "").substring(0, 12);
        String safeName = (name == null || name.isEmpty()) ? file.getName() : name;
        VideoEntry entry = new VideoEntry(id, safeName, mime, file.length(), file, null);
        videos.put(id, entry);
        currentVideo = entry;
        return entry;
    }

    private void handleClient(Socket socket) {
        try (Socket s = socket) {
            s.setSoTimeout(30000);
            InputStream in = s.getInputStream();
            OutputStream out = s.getOutputStream();

            String headerBlock = readHeaders(in);
            if (headerBlock == null || headerBlock.isEmpty()) return;

            String[] lines = headerBlock.split("\r\n");
            if (lines.length == 0) return;

            String[] reqParts = lines[0].split(" ");
            if (reqParts.length < 2) return;
            String method = reqParts[0].toUpperCase(Locale.US);
            String fullPath = reqParts[1];

            String path = fullPath;
            Map<String, String> query = new HashMap<>();
            int qIdx = fullPath.indexOf('?');
            if (qIdx >= 0) {
                path = fullPath.substring(0, qIdx);
                parseQuery(fullPath.substring(qIdx + 1), query);
            }

            Map<String, String> headers = new HashMap<>();
            for (int i = 1; i < lines.length; i++) {
                int c = lines[i].indexOf(':');
                if (c > 0) {
                    headers.put(lines[i].substring(0, c).trim().toLowerCase(Locale.US),
                                lines[i].substring(c + 1).trim());
                }
            }

            if ("OPTIONS".equals(method)) {
                sendSimple(out, "204 No Content", "text/plain", new byte[0]);
                return;
            }

            if ("GET".equals(method) && ("/".equals(path) || "/upload-ui".equals(path))) {
                sendSimple(out, "200 OK", "text/html; charset=utf-8", buildUploadUiHtml().getBytes(StandardCharsets.UTF_8));
                return;
            }

            if ("GET".equals(method) && ("/status".equals(path) || "/current".equals(path))) {
                String json = buildStatusJson();
                sendSimple(out, "200 OK", "application/json; charset=utf-8", json.getBytes(StandardCharsets.UTF_8));
                return;
            }

            if (("GET".equals(method) || "HEAD".equals(method)) && path.startsWith("/video/")) {
                String id = path.substring("/video/".length());
                int dot = id.indexOf('.');
                if (dot > 0) id = id.substring(0, dot);
                VideoEntry entry = "current".equals(id) ? currentVideo : videos.get(id);
                if (entry == null) {
                    sendSimple(out, "404 Not Found", "application/json", "{\"ok\":false,\"error\":\"Video not found\"}".getBytes(StandardCharsets.UTF_8));
                    return;
                }
                serveVideo(out, entry, headers.get("range"), "HEAD".equals(method));
                return;
            }

            if ("POST".equals(method) && "/upload".equals(path)) {
                handleUpload(in, out, headers, query);
                return;
            }

            if ("POST".equals(method) && "/save".equals(path)) {
                handleSaveToDevice(in, out, headers, query);
                return;
            }

            sendSimple(out, "404 Not Found", "application/json", "{\"ok\":false,\"error\":\"Not found\"}".getBytes(StandardCharsets.UTF_8));
        } catch (IOException e) {
            // Normal when video player aborts a range request while seeking
        }
    }

    private void handleUpload(InputStream in, OutputStream out, Map<String, String> headers, Map<String, String> query) throws IOException {
        long contentLength = parseLong(headers.get("content-length"), -1);
        if (contentLength <= 0) {
            sendSimple(out, "400 Bad Request", "application/json", "{\"ok\":false,\"error\":\"Missing Content-Length\"}".getBytes(StandardCharsets.UTF_8));
            return;
        }
        String rawName = query.get("name");
        if (rawName == null || rawName.isEmpty()) rawName = headers.get("x-file-name");
        if (rawName == null || rawName.isEmpty()) rawName = "uploaded-video.mp4";
        String safeName = sanitizeFilename(rawName);
        String mime = query.get("mime");
        if (mime == null || mime.isEmpty()) mime = headers.get("content-type");
        if (mime == null || mime.isEmpty() || mime.contains("octet-stream")) mime = guessMime(safeName);

        File dir = new File(context.getCacheDir(), "localhost_videos");
        if (!dir.exists()) dir.mkdirs();
        // Clean older cached uploads to save phone storage
        File[] existing = dir.listFiles();
        if (existing != null && existing.length > 3) {
            for (File f : existing) f.delete();
        }

        File target = new File(dir, System.currentTimeMillis() + "_" + safeName);
        try (FileOutputStream fos = new FileOutputStream(target)) {
            copyExact(in, fos, contentLength);
        }

        VideoEntry entry = registerFile(target, safeName, mime);
        String json = "{"
                + "\"ok\":true,"
                + "\"id\":\"" + esc(entry.id) + "\","
                + "\"name\":\"" + esc(entry.name) + "\","
                + "\"size\":" + entry.size + ","
                + "\"mime\":\"" + esc(entry.mime) + "\","
                + "\"url\":\"" + esc(getBaseUrl() + "/video/" + entry.id) + "\""
                + "}";
        sendSimple(out, "200 OK", "application/json; charset=utf-8", json.getBytes(StandardCharsets.UTF_8));
    }

    private void handleSaveToDevice(InputStream in, OutputStream out, Map<String, String> headers, Map<String, String> query) throws IOException {
        long contentLength = parseLong(headers.get("content-length"), -1);
        if (contentLength <= 0) {
            sendSimple(out, "400 Bad Request", "application/json", "{\"ok\":false,\"error\":\"Missing Content-Length\"}".getBytes(StandardCharsets.UTF_8));
            return;
        }
        String rawName = query.get("name");
        if (rawName == null || rawName.isEmpty()) rawName = "export-" + System.currentTimeMillis() + ".mp4";
        String safeName = sanitizeFilename(rawName);
        String mime = query.get("mime");
        if (mime == null || mime.isEmpty()) mime = headers.get("content-type");
        if (mime == null || mime.isEmpty()) mime = guessMime(safeName);
        boolean isVideo = mime.startsWith("video/") || safeName.toLowerCase(Locale.US).endsWith(".mp4");

        String savedLocation;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentResolver cr = context.getContentResolver();
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, safeName);
            cv.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            String relPath = (isVideo ? Environment.DIRECTORY_MOVIES : Environment.DIRECTORY_DOWNLOADS) + "/LyricSync";
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, relPath);
            cv.put(MediaStore.MediaColumns.IS_PENDING, 1);

            Uri collection = isVideo ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI : MediaStore.Downloads.EXTERNAL_CONTENT_URI;
            Uri itemUri = cr.insert(collection, cv);
            if (itemUri == null) throw new IOException("MediaStore insert failed");
            try (OutputStream os = cr.openOutputStream(itemUri)) {
                if (os == null) throw new IOException("Cannot open MediaStore OutputStream");
                copyExact(in, os, contentLength);
            }
            cv.clear();
            cv.put(MediaStore.MediaColumns.IS_PENDING, 0);
            cr.update(itemUri, cv, null, null);
            savedLocation = relPath + "/" + safeName;
        } else {
            File baseDir = Environment.getExternalStoragePublicDirectory(
                    isVideo ? Environment.DIRECTORY_MOVIES : Environment.DIRECTORY_DOWNLOADS);
            File dir = new File(baseDir, "LyricSync");
            if (!dir.exists() && !dir.mkdirs()) {
                dir = new File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "LyricSync");
                dir.mkdirs();
            }
            File target = new File(dir, safeName);
            try (FileOutputStream fos = new FileOutputStream(target)) {
                copyExact(in, fos, contentLength);
            }
            MediaScannerConnection.scanFile(context, new String[]{target.getAbsolutePath()}, new String[]{mime}, null);
            savedLocation = target.getAbsolutePath();
        }

        String json = "{\"ok\":true,\"savedPath\":\"" + esc(savedLocation) + "\"}";
        sendSimple(out, "200 OK", "application/json; charset=utf-8", json.getBytes(StandardCharsets.UTF_8));
    }

    private void serveVideo(OutputStream out, VideoEntry entry, String rangeHeader, boolean headOnly) throws IOException {
        long total = entry.size;
        if (entry.file != null) {
            total = entry.file.length();
        } else if (entry.uri != null && total <= 0) {
            try (AssetFileDescriptor afd = context.getContentResolver().openAssetFileDescriptor(entry.uri, "r")) {
                if (afd != null && afd.getLength() > 0) total = afd.getLength();
            } catch (Exception ignored) {}
        }

        long start = 0;
        long end = total > 0 ? (total - 1) : -1;
        boolean partial = false;

        if (rangeHeader != null && rangeHeader.startsWith("bytes=") && total > 0) {
            String spec = rangeHeader.substring(6).split(",")[0].trim();
            int dash = spec.indexOf('-');
            if (dash >= 0) {
                String sPart = spec.substring(0, dash).trim();
                String ePart = spec.substring(dash + 1).trim();
                if (!sPart.isEmpty()) {
                    start = parseLong(sPart, 0);
                    end = ePart.isEmpty() ? (total - 1) : parseLong(ePart, total - 1);
                } else if (!ePart.isEmpty()) {
                    long suffix = parseLong(ePart, 0);
                    start = Math.max(0, total - suffix);
                    end = total - 1;
                }
                if (end >= total) end = total - 1;
                if (start > end || start < 0) {
                    String hdr = "HTTP/1.1 416 Range Not Satisfiable\r\n"
                            + corsHeaders()
                            + "Content-Range: bytes */" + total + "\r\n"
                            + "Connection: close\r\n\r\n";
                    out.write(hdr.getBytes(StandardCharsets.US_ASCII));
                    out.flush();
                    return;
                }
                partial = true;
            }
        }

        long len = (total > 0) ? (end - start + 1) : -1;
        StringBuilder sb = new StringBuilder();
        sb.append(partial ? "HTTP/1.1 206 Partial Content\r\n" : "HTTP/1.1 200 OK\r\n");
        sb.append(corsHeaders());
        sb.append("Content-Type: ").append(entry.mime).append("\r\n");
        sb.append("Accept-Ranges: bytes\r\n");
        if (partial) {
            sb.append("Content-Range: bytes ").append(start).append("-").append(end).append("/").append(total).append("\r\n");
        }
        if (len >= 0) {
            sb.append("Content-Length: ").append(len).append("\r\n");
        }
        sb.append("Cache-Control: no-store\r\n");
        sb.append("Connection: close\r\n\r\n");
        out.write(sb.toString().getBytes(StandardCharsets.US_ASCII));
        out.flush();

        if (headOnly) return;

        byte[] buf = new byte[65536];
        if (entry.file != null) {
            try (RandomAccessFile raf = new RandomAccessFile(entry.file, "r")) {
                raf.seek(start);
                long remaining = len;
                while (remaining > 0) {
                    int r = raf.read(buf, 0, (int) Math.min(buf.length, remaining));
                    if (r < 0) break;
                    out.write(buf, 0, r);
                    remaining -= r;
                }
                out.flush();
            }
        } else if (entry.uri != null) {
            AssetFileDescriptor afd = context.getContentResolver().openAssetFileDescriptor(entry.uri, "r");
            if (afd != null) {
                try (AssetFileDescriptor autoAfd = afd; FileInputStream fis = autoAfd.createInputStream()) {
                    try {
                        FileChannel ch = fis.getChannel();
                        ch.position(autoAfd.getStartOffset() + start);
                    } catch (Exception seekErr) {
                        skipFully(fis, start);
                    }
                    long remaining = len;
                    while (remaining != 0) {
                        int toRead = (remaining > 0) ? (int) Math.min(buf.length, remaining) : buf.length;
                        int r = fis.read(buf, 0, toRead);
                        if (r < 0) break;
                        out.write(buf, 0, r);
                        if (remaining > 0) remaining -= r;
                    }
                    out.flush();
                }
            }
        }
    }

    private void sendSimple(OutputStream out, String status, String contentType, byte[] body) throws IOException {
        String hdr = "HTTP/1.1 " + status + "\r\n"
                + corsHeaders()
                + "Content-Type: " + contentType + "\r\n"
                + "Content-Length: " + body.length + "\r\n"
                + "Cache-Control: no-store\r\n"
                + "Connection: close\r\n\r\n";
        out.write(hdr.getBytes(StandardCharsets.US_ASCII));
        if (body.length > 0) out.write(body);
        out.flush();
    }

    private String corsHeaders() {
        return "Access-Control-Allow-Origin: *\r\n"
                + "Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS, HEAD\r\n"
                + "Access-Control-Allow-Headers: Content-Type, Range, X-File-Name, Authorization\r\n"
                + "Access-Control-Expose-Headers: Content-Length, Content-Range, Accept-Ranges\r\n";
    }

    private String buildStatusJson() {
        StringBuilder sb = new StringBuilder();
        sb.append("{\"ok\":true,\"port\":").append(port)
          .append(",\"url\":\"").append(esc(getBaseUrl()))
          .append("\",\"lanUrl\":\"").append(esc(getLanUrl())).append("\"");
        VideoEntry cv = currentVideo;
        if (cv != null) {
            sb.append(",\"currentVideo\":{")
              .append("\"id\":\"").append(esc(cv.id)).append("\",")
              .append("\"name\":\"").append(esc(cv.name)).append("\",")
              .append("\"size\":").append(cv.size).append(",")
              .append("\"mime\":\"").append(esc(cv.mime)).append("\",")
              .append("\"url\":\"").append(esc(getBaseUrl() + "/video/" + cv.id)).append("\"")
              .append("}");
        } else {
            sb.append(",\"currentVideo\":null");
        }
        sb.append("}");
        return sb.toString();
    }

    private String buildUploadUiHtml() {
        return "<!DOCTYPE html><html lang=\"ar\" dir=\"rtl\"><head><meta charset=\"utf-8\">"
                + "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
                + "<title>رفع فيديو إلى AI Lyric Sync</title>"
                + "<style>body{font-family:system-ui,sans-serif;background:#0b1120;color:#e6ecf5;max-width:520px;margin:40px auto;padding:20px}"
                + ".card{background:#162032;border:1px solid #2a3954;border-radius:14px;padding:20px}"
                + "h1{font-size:1.3rem;color:#f5b94a;margin:0 0 8px}p{color:#8fa1bf;font-size:.9rem}"
                + "input,button{width:100%;padding:12px;border-radius:10px;border:1px solid #2a3954;margin-top:12px;box-sizing:border-box;font-size:1rem}"
                + "button{background:#f5b94a;color:#1a1405;font-weight:700;border:0;cursor:pointer}"
                + ".bar{height:10px;background:#0b1120;border-radius:6px;margin-top:14px;overflow:hidden}.bar i{display:block;height:100%;width:0;background:#4ade80}"
                + "#msg{margin-top:12px;font-size:.9rem;color:#4ade80}</style></head><body>"
                + "<div class=\"card\"><h1>رفع فيديو إلى خادم Localhost</h1>"
                + "<p>اختر فيديو من جهازك ليظهر فورًا داخل تطبيق AI Lyric Sync على الهاتف.</p>"
                + "<input id=\"f\" type=\"file\" accept=\"video/*\">"
                + "<button id=\"b\">رفع الفيديو الآن</button>"
                + "<div class=\"bar\"><i id=\"p\"></i></div><div id=\"msg\"></div></div>"
                + "<script>document.getElementById('b').onclick=function(){"
                + "var f=document.getElementById('f').files[0];if(!f)return alert('اختر فيديو أولًا');"
                + "var x=new XMLHttpRequest();x.open('POST','/upload?name='+encodeURIComponent(f.name)+'&mime='+encodeURIComponent(f.type||'video/mp4'));"
                + "x.upload.onprogress=function(e){if(e.lengthComputable)document.getElementById('p').style.width=(e.loaded/e.total*100)+'%'};"
                + "x.onload=function(){document.getElementById('msg').textContent=x.status===200?'تم الرفع بنجاح! افتح التطبيق واضغط تحديث الفيديو المرفوع.':'خطأ: '+x.responseText};"
                + "x.onerror=function(){document.getElementById('msg').textContent='فشل الاتصال بالخادم'};"
                + "document.getElementById('msg').textContent='جارٍ الرفع...';x.send(f);};</script></body></html>";
    }

    private static String readHeaders(InputStream in) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream(512);
        int state = 0;
        int b;
        while ((b = in.read()) != -1) {
            baos.write(b);
            if (baos.size() > 32768) break;
            if (state == 0 && b == '\r') state = 1;
            else if (state == 1 && b == '\n') state = 2;
            else if (state == 2 && b == '\r') state = 3;
            else if (state == 3 && b == '\n') break;
            else state = 0;
        }
        return baos.size() == 0 ? null : baos.toString("ISO-8859-1");
    }

    private static void copyExact(InputStream in, OutputStream out, long length) throws IOException {
        byte[] buf = new byte[65536];
        long rem = length;
        while (rem > 0) {
            int r = in.read(buf, 0, (int) Math.min(buf.length, rem));
            if (r < 0) break;
            out.write(buf, 0, r);
            rem -= r;
        }
        out.flush();
    }

    private static void skipFully(InputStream in, long n) throws IOException {
        long rem = n;
        while (rem > 0) {
            long s = in.skip(rem);
            if (s <= 0) {
                if (in.read() < 0) break;
                rem--;
            } else {
                rem -= s;
            }
        }
    }

    private static void parseQuery(String qs, Map<String, String> map) {
        for (String pair : qs.split("&")) {
            int eq = pair.indexOf('=');
            try {
                if (eq > 0) {
                    map.put(URLDecoder.decode(pair.substring(0, eq), "UTF-8"),
                            URLDecoder.decode(pair.substring(eq + 1), "UTF-8"));
                }
            } catch (Exception ignored) {}
        }
    }

    private static long parseLong(String v, long def) {
        if (v == null) return def;
        try { return Long.parseLong(v.trim()); } catch (Exception e) { return def; }
    }

    private static String sanitizeFilename(String name) {
        String clean = name.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        return clean.isEmpty() ? "file.bin" : clean;
    }

    private static String guessMime(String name) {
        String n = name.toLowerCase(Locale.US);
        if (n.endsWith(".mp4") || n.endsWith(".m4v")) return "video/mp4";
        if (n.endsWith(".webm")) return "video/webm";
        if (n.endsWith(".mkv")) return "video/x-matroska";
        if (n.endsWith(".mov")) return "video/quicktime";
        if (n.endsWith(".srt")) return "text/plain; charset=utf-8";
        return "application/octet-stream";
    }

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "");
    }

    private static String getLocalIpAddress() {
        try {
            Enumeration<NetworkInterface> ifaces = NetworkInterface.getNetworkInterfaces();
            for (NetworkInterface nif : Collections.list(ifaces)) {
                if (!nif.isUp() || nif.isLoopback()) continue;
                for (InetAddress addr : Collections.list(nif.getInetAddresses())) {
                    if (addr instanceof Inet4Address && !addr.isLoopbackAddress()) {
                        return addr.getHostAddress();
                    }
                }
            }
        } catch (Exception ignored) {}
        return null;
    }
}
