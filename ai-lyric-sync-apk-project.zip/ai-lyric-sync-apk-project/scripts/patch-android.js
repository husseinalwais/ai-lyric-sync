const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const androidDir = path.join(root, 'android');
if (!fs.existsSync(androidDir)) {
  console.error('android/ folder not found. Run `npx cap add android` first.');
  process.exit(1);
}

// 1. Copy native Java plugin & localhost server
const srcJava = path.join(root, 'android-overlay', 'java', 'com', 'lyricsync', 'ai');
const dstJava = path.join(androidDir, 'app', 'src', 'main', 'java', 'com', 'lyricsync', 'ai');
fs.mkdirSync(dstJava, { recursive: true });
for (const file of fs.readdirSync(srcJava)) {
  fs.copyFileSync(path.join(srcJava, file), path.join(dstJava, file));
  console.log('Copied Java:', file);
}

// 2. Copy network_security_config.xml
const srcXml = path.join(root, 'android-overlay', 'res', 'xml', 'network_security_config.xml');
const dstXmlDir = path.join(androidDir, 'app', 'src', 'main', 'res', 'xml');
fs.mkdirSync(dstXmlDir, { recursive: true });
fs.copyFileSync(srcXml, path.join(dstXmlDir, 'network_security_config.xml'));
console.log('Copied network_security_config.xml');

// 3. Patch AndroidManifest.xml
const manifestPath = path.join(androidDir, 'app', 'src', 'main', 'AndroidManifest.xml');
let manifest = fs.readFileSync(manifestPath, 'utf8');

const permissions = [
  '<uses-permission android:name="android.permission.INTERNET" />',
  '<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />',
  '<uses-permission android:name="android.permission.WAKE_LOCK" />',
  '<uses-permission android:name="android.permission.READ_MEDIA_VIDEO" />',
  '<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />',
  '<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="29" />'
];

for (const perm of permissions) {
  const permName = perm.match(/android:name="([^"]+)"/)[1];
  if (!manifest.includes(permName)) {
    manifest = manifest.replace('</manifest>', `    ${perm}\n</manifest>`);
  }
}

const appAttrs = [
  ['android:usesCleartextTraffic', 'android:usesCleartextTraffic="true"'],
  ['android:largeHeap', 'android:largeHeap="true"'],
  ['android:hardwareAccelerated', 'android:hardwareAccelerated="true"'],
  ['android:networkSecurityConfig', 'android:networkSecurityConfig="@xml/network_security_config"']
];

for (const [key, fullAttr] of appAttrs) {
  if (!manifest.includes(key)) {
    manifest = manifest.replace('<application', `<application\n        ${fullAttr}`);
  }
}

fs.writeFileSync(manifestPath, manifest, 'utf8');
console.log('Patched AndroidManifest.xml');
